# Viewport-Editor Integration Test Guide

## Chapter 1: Getting Started

Welcome to the viewport-editor integration test guide. This document
walks through the key features of the viewport-editor MCP server.

### 1.1 Installation

Install the viewport-editor package using pip:

```bash
pip install viewport-editor
```

Or add it to your project dependencies in `pyproject.toml`:

```toml
[dependencies]
viewport-editor = "^0.1.0"
```

### 1.2 Configuration

Create a configuration file at `config.yaml` in your project root.
See the `config.yaml` fixture for a complete example.

## Chapter 2: Core Concepts

### 2.1 Viewports

A **viewport** is a focused window into a file. Instead of loading the
entire file into context, the viewport shows only the visible line range.
This keeps context usage proportional to the window size, not the file size.

Opening a viewport:

```
viewport(action="open", file_path="example.py", height=30)
```

Navigating within a viewport:

```
viewport(action="scroll", viewport_id="vp_1", lines=10)
viewport(action="page-down", viewport_id="vp_1")
viewport(action="jump", viewport_id="vp_1", target="150")
```

### 2.2 Jump Targets

The `jump` action accepts two kinds of targets:

1. **Line number** — a digit string like `"150"` jumps to that line
2. **Text search** — any non-digit string searches for the first line
   containing that substring and jumps to it

Examples:

```
viewport(action="jump", viewport_id="vp_1", target="42")
viewport(action="jump", viewport_id="vp_1", target="def apply_edit")
viewport(action="jump", viewport_id="vp_1", target="## Section Header")
```

### 2.3 Editing

All edits stage into a buffer — they do not write to disk until
explicitly saved or autosave is enabled.

```
edit(action="replace", viewport_id="vp_1", old_text="old", new_text="new")
edit(action="insert-lines", viewport_id="vp_1", after_line=10, new_lines=["added"])
edit(action="delete-lines", viewport_id="vp_1", start_line=5, end_line=8)
```

## Chapter 3: Search and Navigation

### 3.1 In-File Search

The `search` tool finds text patterns with line numbers:

```
search(action="find", pattern="TODO", file_path="example.py")
search(action="find", pattern="def \\w+", regex=True, scope="viewport", viewport_id="vp_1")
```

### 3.2 Project-Wide Search

Without a scope, search scans files in the project directory:

```
search(action="find", pattern="class ViewportConfig")
```

### 3.3 Regex Patterns

The `regex` tool provides pattern testing and escaping:

```
regex(action="test", pattern="\\d{4}-\\d{2}-\\d{2}", text="2025-06-02")
regex(action="escape", pattern="file.txt")
```

## Chapter 4: File Operations

### 4.1 Saving Files

Save buffered changes to disk:

```
file(action="save", viewport_id="vp_1")
```

### 4.2 Save-As and New Files

Create new files or save to different paths:

```
file(action="save-as", viewport_id="vp_1", file_path="output.txt")
file(action="new", file_path="scratch.txt", content="initial content")
```

### 4.3 Conflict Detection

If a file changes on disk between when you opened it and when you save,
the server warns you about the conflict before overwriting.

## Chapter 5: Clipboard and Stashing

### 5.1 Copy and Paste

Copy and paste text between viewports:

```
clipboard(action="copy", viewport_id="vp_1", start_line=10, end_line=20)
clipboard(action="paste", viewport_id="vp_2", after_line=5)
```

### 5.2 Stash and Pop

Stash clipboard content for later retrieval:

```
clipboard(action="stash", viewport_id="vp_1")
clipboard(action="pop", viewport_id="vp_1")
```

## Appendix A: Error Handling

Common error messages and their meanings:

| Error | Meaning | Resolution |
|-------|---------|------------|
| `ViewportNotFoundError` | No viewport with that ID | Open the file first |
| `LineOutOfRangeError` | Line number exceeds file length | Check file length with `list` |
| `JumpTargetNotFoundError` | Target text not in file | Verify the target string exists |
| `ConflictError` | File changed on disk | Review changes or force save |

## Appendix B: Default Keybindings

There are no default keybindings — all interaction is through the MCP
protocol. Configure your client to map keys to viewport-editor actions.

## Appendix C: Performance Notes

- Viewports load only the visible window, not the entire file
- Large files (100k+ lines) remain responsive because navigation is O(1)
- Autosave flushes to disk on every edit — use selectively
- Search is linear in file size; regex search compiles patterns once