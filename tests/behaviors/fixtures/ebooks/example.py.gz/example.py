"""Example module for viewport-editor code navigation testing.

Tests: jump to def/class, search for symbols, regex pattern matching,
edit within function bodies.
"""


class ViewportConfig:
    """Configuration for a single viewport instance."""

    def __init__(self, height: int = 50, autosave: bool = False):
        self.height = height
        self.autosave = autosave
        self.display_mode = "cat"

    def to_dict(self) -> dict:
        """Serialize config to dictionary."""
        return {
            "height": self.height,
            "autosave": self.autosave,
            "display_mode": self.display_mode,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ViewportConfig":
        """Deserialize config from dictionary."""
        return cls(
            height=data.get("height", 50),
            autosave=data.get("autosave", False),
        )


class SessionManager:
    """Manage open viewport sessions."""

    def __init__(self, max_sessions: int = 10):
        self.max_sessions = max_sessions
        self.sessions: dict[str, list[str]] = {}

    def create_session(self, session_id: str) -> None:
        """Create a new session with empty viewport list."""
        if session_id in self.sessions:
            raise ValueError(f"session {session_id} already exists")
        self.sessions[session_id] = []

    def destroy_session(self, session_id: str) -> None:
        """Remove session and all its viewports."""
        if session_id not in self.sessions:
            raise KeyError(f"session {session_id} not found")
        del self.sessions[session_id]

    def list_sessions(self) -> list[str]:
        """Return all active session IDs."""
        return list(self.sessions.keys())


def apply_edit(content: str, old_text: str, new_text: str) -> tuple[str, dict]:
    """Apply a single text replacement.

    Returns the modified content and a summary dict with change stats.
    """
    if old_text not in content:
        msg = "old_text not found in content"
        raise ValueError(msg)

    count = content.count(old_text)
    result = content.replace(old_text, new_text)

    stats = {
        "replacements": count,
        "old_length": len(old_text),
        "new_length": len(new_text),
    }

    return result, stats


def format_line_number(line_num: int, total_lines: int, width: int = 4) -> str:
    """Format a line number with right-justified padding."""
    return str(line_num).rjust(width) + " | "


def detect_line_ending(content: str) -> str:
    """Detect the dominant line ending in content.

    Returns '\\n', '\\r\\n', or '\\r'.
    """
    crlf = content.count("\r\n")
    lf = content.count("\n") - crlf
    cr = content.count("\r") - crlf

    if crlf >= lf and crlf >= cr:
        return "\r\n"
    if lf >= cr:
        return "\n"
    return "\r"


# Module-level constants
MAX_VIEWPORT_HEIGHT = 200
MIN_VIEWPORT_HEIGHT = 5
DEFAULT_SESSION_TTL = 1800  # seconds
VERSION = "0.1.0"